````md
# CrewKart

CrewKart is a smart workforce & service marketplace platform built with:

- Next.js
- Express.js
- MongoDB
- JWT Authentication
- Zustand
- Tailwind CSS

---

# Features

## Client
- Signup/Login
- Google Login
- Book Services
- Dashboard
- Live Booking Tracking

## Crew
- Accept/Reject Bookings
- Availability Toggle
- Crew Dashboard

## Admin
- Assign Crew
- Manage Bookings
- View Operations

---

# Tech Stack

## Frontend
- Next.js
- Tailwind CSS
- Zustand
- Axios
- NextAuth

## Backend
- Express.js
- MongoDB
- JWT
- Mongoose

---

# Installation

## 1. Clone Project

```bash
git clone YOUR_GITHUB_LINK
````

---

# Frontend Setup

```bash
cd crewkart-frontend
npm install
npm run dev
```

---

# Backend Setup

```bash
cd crewkart-backend
npm install
npm run dev
```

---

# Environment Variables

## Frontend (.env.local)

```env
NEXTAUTH_SECRET=your_secret
NEXTAUTH_URL=http://localhost:3000

GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_secret
```

---

## Backend (.env)

```env
PORT=5000
MONGO_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
```

---

# Default Ports

| Service  | Port |
| -------- | ---- |
| Frontend | 3000 |
| Backend  | 5000 |

---

# Author

CrewKart Team

```
```
