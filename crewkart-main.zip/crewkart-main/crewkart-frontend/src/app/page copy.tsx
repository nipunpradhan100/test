"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import Navbar from "@/components/navbar/Navbar";
import api from "@/services/api";

const FadeIn = ({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.6, delay }}
    className={className}
  >
    {children}
  </motion.div>
);

export default function Home() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleQuickSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery) return;
    setLoading(true);
    try {
      await api.post("/bookings/create", { city: searchQuery, location: searchQuery, service: "Photography", packageName: "Basic", date: "2024-12-01", time: "10:00" });
      router.push("/login");
    } catch (error: any) { alert(error.response?.data?.message || "Failed"); }
    finally { setLoading(false); }
  };

  return (
    <main className="bg-[#0D1026] text-white">
      <Navbar />

      {/* ========================================= */}
      {/* SECTION 1: HERO (DARK NAVY) */}
      {/* ========================================= */}
      <section className="bg-[#0D1026] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 md:px-10 py-20 md:py-32 grid lg:grid-cols-2 gap-16 items-center">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-5xl md:text-6xl font-black leading-tight mb-6">
              Hire Top Creative Talent. <span className="text-[#7B2CFF]">Instantly.</span>
            </h1>
            <p className="text-lg text-white/50 mb-10 max-w-md leading-relaxed">
              Find the best professionals to execute your tasks, manage your events, and bring your creative vision to life.
            </p>

            <form onSubmit={handleQuickSearch} className="flex flex-col sm:flex-row gap-4 max-w-xl">
              <div className="relative flex-1">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40">📍</span>
                <input type="text" required placeholder="Select city" className="w-full rounded-xl border border-white/10 bg-white/5 pl-12 pr-6 py-4 text-base font-medium text-white outline-none focus:border-[#7B2CFF] transition-all placeholder:text-white/30" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              <button type="submit" disabled={loading || !searchQuery} className="rounded-xl bg-[#7B2CFF] px-8 py-4 text-base font-bold text-white shadow-lg shadow-[#7B2CFF]/20 disabled:opacity-50 transition-all hover:bg-[#6a1ff0] whitespace-nowrap">
                {loading ? "Finding..." : "Book Now"}
              </button>
            </form>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1, delay: 0.2 }} className="hidden lg:block relative">
            <img src="https://images.unsplash.com/photo-1558618666-fcd25c85f82e?q=80&w=1000&auto=format&fit=crop" alt="Creative Gear" className="relative rounded-2xl shadow-2xl shadow-black/50 w-full object-cover aspect-video border border-white/10" />
          </motion.div>
        </div>
      </section>

      {/* ========================================= */}
      {/* SECTION 2: CATEGORIES (LIGHT MODE) */}
      {/* ========================================= */}
      <section className="bg-white text-gray-900 py-24">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <FadeIn>
            <div className="flex justify-between items-end mb-12">
              <div>
                <p className="text-[#7B2CFF] text-sm font-bold uppercase tracking-widest mb-2">Categories</p>
                <h2 className="text-3xl font-bold text-gray-900">Browse By Categories</h2>
              </div>
              <button className="hidden md:block text-sm font-semibold text-gray-400 hover:text-[#7B2CFF] transition">View All →</button>
            </div>
          </FadeIn>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[
              { name: "Videographer", icon: "🎬" },
              { name: "Photographer", icon: "📸" },
              { name: "DJ & Music", icon: "🎵" },
              { name: "Editor", icon: "💻" },
              { name: "Event Planner", icon: "🎉" },
              { name: "Designer", icon: "🎨" }
            ].map((cat, i) => (
              <FadeIn key={i} delay={i * 0.05}>
                <div className="bg-gray-50 border border-gray-100 rounded-2xl p-6 flex flex-col items-center text-center gap-3 cursor-pointer transition-all hover:bg-purple-50 hover:border-purple-200 group">
                  <span className="text-4xl group-hover:scale-110 transition-transform">{cat.icon}</span>
                  <span className="text-sm font-semibold text-gray-700">{cat.name}</span>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================= */}
      {/* SECTION 3: HOW IT WORKS (LIGHT GREY MODE) */}
      {/* ========================================= */}
      <section className="bg-[#F8FAFC] text-gray-900 py-24 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <FadeIn>
            <div className="text-center mb-16">
              <p className="text-[#7B2CFF] text-sm font-bold uppercase tracking-widest mb-2">Process</p>
              <h2 className="text-3xl font-bold text-gray-900">How it works</h2>
            </div>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-10 relative">
            {/* Connecting Lines */}
            <div className="hidden md:block absolute top-16 left-[calc(33.33%-20px)] right-[calc(33.33%-20px)] h-[2px] bg-gray-200" />
            <div className="hidden md:block absolute top-16 left-[calc(66.66%-20px)] right-[calc(0%-20px)] h-[2px] bg-gray-200" />

            {[
              { step: "01", title: "Post Your Requirement", desc: "Tell us what you need, where, and when. It takes less than a minute." },
              { step: "02", title: "Get Matched Instantly", desc: "Our system matches you with top-tier verified professionals nearby." },
              { step: "03", title: "Hire & Collaborate", desc: "Review profiles, chat, and hire the perfect crew for your project." }
            ].map((item, i) => (
              <FadeIn key={i} delay={i * 0.2}>
                <div className="relative text-center">
                  <div className="w-32 h-32 mx-auto mb-6 rounded-full border-2 border-purple-100 bg-white flex items-center justify-center text-4xl font-black text-[#7B2CFF] relative z-10 shadow-sm">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-gray-900">{item.title}</h3>
                  <p className="text-gray-500 leading-relaxed max-w-xs mx-auto text-sm">{item.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================= */}
      {/* SECTION 4: EVERYTHING YOU NEED (DARK NAVY MODE) */}
      {/* ========================================= */}
      <section className="bg-[#0D1026] py-24 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <FadeIn>
            <div className="text-center mb-16 max-w-2xl mx-auto">
              <p className="text-[#7B2CFF] text-sm font-bold uppercase tracking-widest mb-2">Features</p>
              <h2 className="text-3xl font-bold text-white mb-4">Everything You Need, All In One Place</h2>
              <p className="text-white/40">From finding talent to final delivery, our platform handles the complexities.</p>
            </div>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: "🛡️", title: "Verified Professionals", desc: "Every crew member is background checked and skill verified." },
              { icon: "💰", title: "Transparent Pricing", desc: "No hidden fees. Get quotes upfront before you commit." },
              { icon: "⚡", title: "Instant Booking", desc: "Skip lengthy negotiations. Book your crew in 3 clicks." }
            ].map((feature, i) => (
              <FadeIn key={i} delay={i * 0.1}>
                <div className="bg-white/5 border border-white/10 rounded-2xl p-8 h-full transition-all hover:border-[#7B2CFF]/50 hover:-translate-y-1">
                  <div className="w-14 h-14 rounded-xl bg-[#7B2CFF]/10 flex items-center justify-center text-2xl mb-6">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{feature.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================= */}
      {/* SECTION 5: POPULAR PROS (LIGHT MODE) */}
      {/* ========================================= */}
      <section className="bg-white text-gray-900 py-24 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <FadeIn>
            <div className="flex justify-between items-end mb-12">
              <div>
                <p className="text-[#7B2CFF] text-sm font-bold uppercase tracking-widest mb-2">Top Rated</p>
                <h2 className="text-3xl font-bold text-gray-900">Popular Creative Professionals</h2>
              </div>
              <button className="hidden md:block text-sm font-semibold text-gray-400 hover:text-[#7B2CFF] transition">View All →</button>
            </div>
          </FadeIn>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Raj Patel", role: "Cinematographer", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop", rating: "4.9", reviews: 120 },
              { name: "Anya Sharma", role: "Photographer", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop", rating: "5.0", reviews: 89 },
              { name: "David Kim", role: "Event DJ", img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop", rating: "4.8", reviews: 204 },
              { name: "Priya Singh", role: "Graphic Designer", img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200&auto=format&fit=crop", rating: "4.9", reviews: 56 }
            ].map((pro, i) => (
              <FadeIn key={i} delay={i * 0.1}>
                <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm group hover:shadow-xl hover:border-purple-100 transition-all">
                  <div className="h-56 overflow-hidden">
                    <img src={pro.img} alt={pro.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-bold text-gray-900">{pro.name}</h3>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <span className="text-amber-400">★</span> {pro.rating} <span className="text-xs text-gray-400">({pro.reviews})</span>
                      </div>
                    </div>
                    <p className="text-gray-500 text-sm mb-5">{pro.role}</p>
                    <button className="w-full py-3 rounded-lg border border-[#7B2CFF] text-[#7B2CFF] text-sm font-bold hover:bg-[#7B2CFF] hover:text-white transition-all">
                      View Profile
                    </button>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================= */}
      {/* SECTION 6: STATS & FOOTER (DARK NAVY MODE) */}
      {/* ========================================= */}
      <footer className="bg-[#080b18] py-24 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <div className="grid lg:grid-cols-2 gap-16 mb-20">
            <FadeIn>
              <div className="grid grid-cols-2 gap-x-12 gap-y-10">
                {[
                  { num: "2,500+", label: "Verified Crew Members" },
                  { num: "98%", label: "Client Satisfaction Rate" },
                  { num: "5,000+", label: "Projects Completed" },
                  { num: "24/7", label: "Active Support" }
                ].map((stat, i) => (
                  <div key={i}>
                    <p className="text-5xl font-black text-white mb-2">{stat.num.split('+')[0]}<span className="text-[#7B2CFF]">+{stat.num.split('+')[1] || ''}</span></p>
                    <p className="text-white/40 font-medium">{stat.label}</p>
                  </div>
                ))}
              </div>
            </FadeIn>

            <FadeIn delay={0.2}>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-10 h-full flex flex-col justify-center">
                <div className="flex gap-1 text-amber-400 text-2xl mb-6">★★★★★</div>
                <p className="text-white/70 text-lg leading-relaxed italic mb-8">"CrewKart completely transformed how we handle event logistics. The talent pool is incredible, and the platform is so smooth to use."</p>
                <div className="flex items-center gap-4">
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=50&auto=format&fit=crop" alt="Client" className="w-12 h-12 rounded-full object-cover border-2 border-[#7B2CFF]/30" />
                  <div>
                    <p className="font-bold text-white">Sarah Jenkins</p>
                    <p className="text-white/40 text-sm">Head of Productions, Eventify</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/30 text-sm">© 2024 CrewKart. All rights reserved.</p>
            <div className="flex gap-6 text-sm text-white/30">
              <span className="hover:text-[#7B2CFF] cursor-pointer transition">Privacy Policy</span>
              <span className="hover:text-[#7B2CFF] cursor-pointer transition">Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}