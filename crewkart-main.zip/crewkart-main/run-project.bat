
@echo off

start cmd /k "cd crewkart-frontend && npm run dev"

start cmd /k "cd crewkart-backend && npm run dev"

echo CrewKart Started Successfully!
pause
