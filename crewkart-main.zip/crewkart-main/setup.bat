
@echo off

echo Installing Frontend Dependencies...
cd crewkart-frontend
call npm install

echo.

echo Installing Backend Dependencies...
cd ../crewkart-backend
call npm install

echo.
echo Setup Completed Successfully!
pause
